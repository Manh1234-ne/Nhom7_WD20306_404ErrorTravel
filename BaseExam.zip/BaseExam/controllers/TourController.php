<?php
require_once PATH_MODEL . 'Tour.php';
require_once PATH_MODEL . 'NhanSu.php';

class TourController
{
    protected $model;
    protected $nhanSuModel;

    public function __construct()
    {
        $this->model = new Tour();
        $this->nhanSuModel = new NhanSu();
    }

    public function index()
    {
        $tours = $this->model->all();
        require PATH_VIEW . 'tours/index.php';
    }

    public function add()
    {
        $hdvList = $this->nhanSuModel->allHDV();
        require PATH_VIEW . 'tours/add.php';
    }

    public function store()
    {
        $data = [
            'ten_tour' => $_POST['ten_tour'] ?? '',
            'loai_tour' => $_POST['loai_tour'] ?? '',
            'mo_ta' => $_POST['mo_ta'] ?? '',
            'nhan_su_id' => $_POST['nhan_su_id'] ?? null,
            'gia' => $_POST['gia'] ?? 0,
            'chinh_sach' => $_POST['chinh_sach'] ?? '',
            'nha_cung_cap' => $_POST['nha_cung_cap'] ?? '',
            'mua' => $_POST['mua'] ?? ''
        ];

        if (!empty($_FILES['hinh_anh']['name'])) {
            $data['hinh_anh'] = upload_file('tour', $_FILES['hinh_anh']);
        }

        // Dùng create() của Tour model để lấy id trả về
        $tour_id = $this->model->create($data);

        if ($tour_id) {
            if (!empty($_FILES['album']['name'][0])) {
                foreach ($_FILES['album']['name'] as $key => $name) {
                    if (empty($_FILES['album']['tmp_name'][$key]))
                        continue;
                    $file_arr = [
                        'name' => $_FILES['album']['name'][$key],
                        'tmp_name' => $_FILES['album']['tmp_name'][$key]
                    ];
                    $file_name = upload_file('tour/album', $file_arr);
                    $this->model->insertAlbum($tour_id, $file_name);
                }
            }
        }

        header('Location: ?action=tours');
        exit;
    }

    public function edit()
    {
        $id = $_GET['id'] ?? null;
        if (!$id)
            die("ID tour không tồn tại");

        $tour = $this->model->find($id);
        $album = $this->model->getAlbum($id);
        $hdvList = $this->nhanSuModel->allHDV();

        require PATH_VIEW . 'tours/edit.php';
    }

    public function update()
    {
        $id = $_POST['id'] ?? null;
        if (!$id)
            die("ID tour không tồn tại");

        $data = [
            'ten_tour' => $_POST['ten_tour'] ?? '',
            'loai_tour' => $_POST['loai_tour'] ?? '',
            'mo_ta' => $_POST['mo_ta'] ?? '',
            'nhan_su_id' => $_POST['nhan_su_id'] ?? null,
            'gia' => $_POST['gia'] ?? 0,
            'chinh_sach' => $_POST['chinh_sach'] ?? '',
            'nha_cung_cap' => $_POST['nha_cung_cap'] ?? '',
            'mua' => $_POST['mua'] ?? ''
        ];

        if (!empty($_FILES['hinh_anh']['name'])) {
            $data['hinh_anh'] = upload_file('tour', $_FILES['hinh_anh']);
        }

        $this->model->update($id, $data);

        if (!empty($_POST['delete_album'])) {
            foreach ($_POST['delete_album'] as $album_id) {
                $this->model->deleteAlbum($album_id);
            }
        }

        if (!empty($_FILES['album']['name'][0])) {
            foreach ($_FILES['album']['name'] as $key => $name) {
                if (empty($_FILES['album']['tmp_name'][$key]))
                    continue;
                $file_arr = [
                    'name' => $_FILES['album']['name'][$key],
                    'tmp_name' => $_FILES['album']['tmp_name'][$key]
                ];
                $file_name = upload_file('tour/album', $file_arr);
                $this->model->insertAlbum($id, $file_name);
            }
        }

        header('Location: ?action=tours');
        exit;
    }

    public function delete()
    {
        $id = $_GET['id'] ?? null;
        if ($id) {
            $this->model->delete($id);
        }
        header('Location: ?action=tours');
        exit;
    }

    /**
     * Chi tiết tour: ưu tiên nhan_su_id, nếu không có -> lấy theo loai_tour
     */
    public function detail()
    {
        $id = $_GET['id'] ?? null;
        if (!$id)
            die("Không tìm thấy ID tour");

        $tour = $this->model->find($id);
        $album = $this->model->getAlbum($id);

        // Lấy HDV theo nhan_su_id nếu có
        $hdv = $this->model->getHDVByTour($id);

        // Nếu không có HDV được gán, thử lấy HDV mặc định từ DB theo loai_hdv (nếu tồn tại)
        if (!$hdv) {
            // Normalize key: ví dụ 'trong_nuoc', 'quoc_te', 'yeu_cau'
            $loai_key = strtolower(str_replace(' ', '_', $tour['loai_tour'] ?? ''));

            // Thử lấy từ DB (cột loai_hdv nếu admin đã thêm)
            $hdv = $this->model->getDefaultHDVFromDB($loai_key);

            // Nếu vẫn không có, dùng mapping hard-coded
            if (!$hdv) {
                $map = [
                    'trong_nuoc' => [
                        'ho_ten' => 'Nguyễn Văn A',
                        'so_dien_thoai' => '0909 111 222',
                        'email' => 'hdv-trongnuoc@travel.test',
                        'ngon_ngu' => 'Tiếng Việt, Tiếng Anh',
                        'kinh_nghiem' => '3 năm',
                        'danh_gia' => '4.5'
                    ],
                    'quoc_te' => [
                        'ho_ten' => 'Trần Thị B',
                        'so_dien_thoai' => '0909 222 333',
                        'email' => 'hdv-quocte@travel.test',
                        'ngon_ngu' => 'Tiếng Anh, Tiếng Nhật',
                        'kinh_nghiem' => '6 năm',
                        'danh_gia' => '4.9'
                    ],
                    'yeu_cau' => [
                        'ho_ten' => 'Phạm Minh C',
                        'so_dien_thoai' => '0909 333 444',
                        'email' => 'hdv-yeucau@travel.test',
                        'ngon_ngu' => 'Tiếng Việt, Tiếng Trung',
                        'kinh_nghiem' => '4 năm',
                        'danh_gia' => '4.7'
                    ],
                ];

                $hdv = $map[$loai_key] ?? [
                    'ho_ten' => 'Hướng dẫn viên mặc định',
                    'so_dien_thoai' => '0999 888 777',
                    'email' => 'default@travel.test',
                    'ngon_ngu' => 'Tiếng Việt',
                    'kinh_nghiem' => '2 năm',
                    'danh_gia' => '4.0'
                ];
            }
        }

        require PATH_VIEW . 'tours/detail.php';
    }
}
