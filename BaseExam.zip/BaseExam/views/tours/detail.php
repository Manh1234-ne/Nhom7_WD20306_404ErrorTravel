<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <title>Chi tiết Tour</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f5f5f5;
        }

        .sidebar {
            width: 220px;
            background: #2c3e50;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            color: #fff;
            display: flex;
            flex-direction: column;
        }

        .sidebar h2 {
            text-align: center;
            padding: 20px 0;
            border-bottom: 1px solid #34495e;
        }

        .sidebar a {
            padding: 15px 20px;
            color: #fff;
            text-decoration: none;
            display: flex;
            align-items: center;
        }

        .sidebar a:hover {
            background: #34495e;
        }

        .sidebar i {
            margin-right: 10px;
        }

        .content {
            margin-left: 220px;
            padding: 30px;
        }

        .section {
            background: #fff;
            padding: 25px;
            border-radius: 10px;
            margin-bottom: 25px;
            box-shadow: 0 3px 8px rgba(0, 0, 0, 0.1);
        }

        .section h2,
        .section h3 {
            margin-top: 0;
        }

        .album-img {
            border-radius: 8px;
            margin: 8px;
            transition: 0.2s;
        }

        .album-img:hover {
            transform: scale(1.08);
        }

        .btn-back {
            margin-top: 20px;
            display: inline-block;
            padding: 10px 15px;
            background: #3498db;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
        }

        .btn-back:hover {
            background: #2980b9;
        }

        .box-highlight {
            background: #fff5eb;
            padding: 20px;
            border-radius: 10px;
        }

        img {
            border-radius: 6px;
        }
    </style>
</head>

<body>

    <div class="sidebar">
        <h2>404 Error Travel</h2>
        <a href="?action=home"><i class="fa fa-home"></i>Trang chủ</a>
        <a href="?action=tours"><i class="fa fa-suitcase"></i>Danh sách Tour</a>
        <a href="?action=nhansu"><i class="fa fa-user"></i>Quản lý nhân sự</a>
        <a href="?action=danhmuc"><i class="fa fa-list"></i>Danh Mục Tour</a>
        <a href="?action=qlbooking"><i class="fa fa-ticket"></i>Quản lý Booking</a>
        <a href="?action=yeucau"><i class="fa fa-star"></i>Ghi chú đặc biệt</a>
    </div>

    <div class="content">
        <h1>Chi tiết Tour: <?= htmlspecialchars($tour["ten_tour"]) ?></h1>

        <!-- THÔNG TIN CƠ BẢN -->
        <div class="section">
            <h2>Thông tin cơ bản</h2>

            <p><strong>Tên tour:</strong> <?= $tour["ten_tour"] ?></p>
            <p><strong>Mô tả:</strong> <?= nl2br($tour["mo_ta"]) ?></p>
            <p><strong>Chính sách:</strong> <?= nl2br($tour["chinh_sach"]) ?></p>
            <p><strong>Nhà cung cấp:</strong> <?= $tour["nha_cung_cap"] ?></p>

            <h3>Ảnh đại diện:</h3>
            <?php if (!empty($tour["hinh_anh"])): ?>
                <img src="assets/uploads/<?= $tour["hinh_anh"] ?>" width="350">
            <?php else: ?>
                <p>Chưa có ảnh đại diện.</p>
            <?php endif; ?>

            <h3>Album ảnh:</h3>
            <?php if (!empty($album)): ?>
                <?php foreach ($album as $img): ?>
                    <img class="album-img" src="assets/uploads/tour/album/<?= $img->file_name ?>" width="150">
                <?php endforeach; ?>
            <?php else: ?>
                <p>Chưa có ảnh album.</p>
            <?php endif; ?>
        </div>

        <!-- LỊCH TRÌNH -->
        <div class="section">
            <h2>Lịch trình</h2>
            <p><strong>Hoạt động:</strong> <?= $tour["lich_trinh_hoat_dong"] ?? "Chưa cập nhật" ?></p>
            <p><strong>Địa điểm:</strong> <?= $tour["dia_diem"] ?? "Chưa cập nhật" ?></p>
            <p><strong>Mô tả chi tiết:</strong>
                <?= isset($tour["mo_ta_lich_trinh"]) ? nl2br($tour["mo_ta_lich_trinh"]) : "Chưa cập nhật" ?>
            </p>
        </div>

        <!-- HƯỚNG DẪN VIÊN -->
        <h3>Hướng Dẫn Viên Phụ Trách</h3>

        <?php if ($hdv && $hdv['id']): ?>
            <div class="card p-3 shadow-sm">
                <h4><?= $hdv['ho_ten'] ?></h4>
                <p><strong>Số điện thoại:</strong> <?= $hdv['so_dien_thoai'] ?></p>
                <p><strong>Email:</strong> <?= $hdv['email'] ?></p>
                <p><strong>Ngôn ngữ:</strong> <?= $hdv['ngon_ngu'] ?></p>
                <p><strong>Kinh nghiệm:</strong> <?= $hdv['kinh_nghiem'] ?></p>
                <p><strong>Đánh giá:</strong> <?= $hdv['danh_gia'] ?>/5 ⭐</p>
            </div>
        <?php else: ?>
            <p><em>Tour này chưa được phân công hướng dẫn viên.</em></p>
        <?php endif; ?>


        <a href="?action=tours" class="btn-back">← Quay lại danh sách</a>
        <a href="?action=dat_tour&id=<?= $tour['id'] ?>" class="btn-back" style="background:#27ae60; margin-left:10px;">
            Đặt tour →
        </a>
    </div>

</body>

</html>