<?php
require_once 'BaseModel.php';

class NhanSu extends BaseModel
{
    protected $table = 'huong_dan_vien';

    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Lấy danh sách HDV: id + ho_ten (để hiển thị select)
     */
    public function allHDV()
    {
        $sql = "SELECT hdv.id, nd.ho_ten
                FROM huong_dan_vien hdv
                LEFT JOIN nguoi_dung nd ON nd.id = hdv.nguoi_dung_id
                ORDER BY nd.ho_ten ASC";
        $stmt = $this->db->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Lấy chi tiết HDV kèm thông tin nguoi_dung
     */
    public function findWithUser($id)
    {
        $sql = "SELECT hdv.*, nd.ho_ten, nd.so_dien_thoai, nd.email
                FROM huong_dan_vien hdv
                LEFT JOIN nguoi_dung nd ON nd.id = hdv.nguoi_dung_id
                WHERE hdv.id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}
