<?php
require_once "BaseModel.php";

class HuongDanVien extends BaseModel
{
    protected $table = "huong_dan_vien";
}

?>